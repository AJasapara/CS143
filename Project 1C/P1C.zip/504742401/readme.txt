FILE DESCRIPTIONS
add-actor-director.php: A page that lets users to add actor and/or director information.

add-movie.php: A page that lets users to add movie information.

add-comments.php: A page that lets users to add comments to movies. 

add-actor-to-movie.php: A page that lets users to add "actor to movie" relation(s).

add-director-to-movie.php: A page that lets users to add "director to movie" relation(s). 

actorInfo.php: A page that shows actor information. Show links to the movies that the actor was in.

movieInfo.php: A page that shows movie information.
Show Title, Producer, MPAA Rating, Director, Genre of this movie.
Show links to the actors/actresses that were in this movie.
Show the average score of the movie based on user feedbacks.
Show all user comments.
Contain "Add Comment" button which links to add-comments.php where users can add comments.


search.php: A page that lets users search for an actor/actress/movie through a keyword search interface. Links to movieInfo.php and actorInfo.php when user clicks on a movie or actor



Brittany did the 5 input pages and Arpit did the 2 browsing and 1 search page. In the future, we believe that we should work together in person more often in order to collaborate easily. 